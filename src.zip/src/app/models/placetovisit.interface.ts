export interface placeToVisit{
    name:'string'
    description:'string'
    images:'string'
}